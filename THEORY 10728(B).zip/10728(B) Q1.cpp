// Create a program that takes user input and stores it in a binary search tree and displays the tree in all orders of traversal
// the input should be 10, 2, 81, 1, 8, 13, 94, 4, 9, and 64.
#include<iostream>
using namespace std;
class Tree
{	
	public:
	int value;
	Tree *left;
	Tree *right;
		
	Tree()
	{
	value=0;
	left=NULL;
	right=NULL;	
	}
	
	TreeNode(int v)
	{
	value=v;
	left=NULL;
	right=NULL;
	}
			
};

class bstree
{
	public:
	Tree * root;
	bstree()
	{
	root=NULL;
	}
	bool Empty()
	{
	if(root==NULL)
	{
	return true;
	}
	else
	{
	return false;		
	}		
    }
		
	void inserNode(Tree *new_node) // insert
	{
	if(root==NULL)
	{
	root=new_node;
	cout<<"Inserted as root node"<<endl;
	}
	else
	{
	Tree * temp= root;
	while(temp!=NULL)
	{
	if(new_node->value==temp->value)
	{
    cout<<"Value Already Exist"<<endl;
	return;
	}
	else if((new_node->value<temp->value)&&(temp->left==NULL))
	{
	temp->left=new_node;
	cout<<"Value inmserted to the left"<<endl;
	break;
	}
	else if((new_node->value<temp->value))
	{
	temp= temp->left;
    }
	else if((new_node->value>temp->value)&&(temp->right==NULL))
	{
	temp->right=new_node;
	cout<<"Value inserted to the right"<<endl;
	break;
	}
	else
	{
	temp=temp->right;
	}		
	}
	}
	}	
	
	void printPreOrder(Tree * r) // preorder
	{ 
	if(r==NULL)
	{
	return;
	}
	cout<<r->value<< " ";
	printPreOrder(r->left);
	printPreOrder(r->right);	
	}
		
	void printInorder(Tree *r) // inorder
	{
	if(r==NULL)
	{
	return;
	}
	printInorder(r->left);
	cout<<r->value<<" ";
	printInorder(r->right);
	}
		
	void printPostOrder(Tree *r) // postorder
	{
	if(r==NULL)
	{
	return;
	}
	printPostOrder(r->left);	
	printPostOrder(r->right);
	cout<<r->value<<" ";
	}
};

int main()
{
	int choice;
	bstree obj;
	while(1)
	{
	cout<<"Enter 1 to Insert Data "<<endl;
	cout<<"Enter 2 to Display Data "<<endl;
	cin>>choice;
		
	Tree *t = new Tree();
	
	switch(choice)
	{
	case 1:
	int val;
	cout<<"Enter value to insert"<<endl;
	cin>>val;
	t->value=val;
	obj.inserNode(t);
	break;
		
	case 2:
	cout<<"Display in PreOrder"<<endl;
	obj.printPreOrder(obj.root);
	cout<<endl;
		
	cout<<"Display in In-Order"<<endl;
	obj.printInorder(obj.root);
	cout<<endl;
		
	cout<<"Display in Post-Order"<<endl;
	obj.printPostOrder(obj.root);
	cout<<endl;
	break;
	}
	}
}
