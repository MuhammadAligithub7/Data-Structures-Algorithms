//	Create a student's database using doubly linked list, the database should be able to dynamically use the following function.
//	Add new student
//	Search Student
//	Delete student 
//	Update student
//   In addition to the above functions, the users should also be able to display the data in sorted order according to the user's choice of
//   sorting according to Name or Roll number.

#include<iostream>
using namespace std;
class node{
	
	int id;
	string name;
	int size;
	node *next;
	node *prev;
	node *head,*tail,*temp,*current,*c;

	public:
	node()
	{
	head= NULL;
	tail= NULL;
	current=NULL;
	c=NULL;
	temp=NULL;	
	}
		
	void add();
	void search();
	void del();
	void update();
	void show();
	void traverseh();
	void traverset();

};

void node::add()
{
	int val;
	string name;
	cout<<"Enter studen rollno "<<endl;
	cin>>val;
	cout<<"Enter studen Name "<<endl;
	cin>>name;
		
	temp = new node();
	temp->next=NULL;
	temp->prev=NULL;
	temp->id=val;
	temp->name=name;
	size++;
	
	if(head==NULL)
	{
	head=temp;
	tail=temp;
	}
	else
	{
	tail->next=temp;
	tail->prev=tail;
	tail=tail->next;	
	}
}

void node::search() // search fun
{
	int val;
	cout<<"enter Student Rollno to search "<<endl;
	cin>>val;
	
	if(head==NULL)
	{
	cout<<"No Data"<<endl;
	}
	
    current = head;
    while(current!=NULL) 
    {
    if(current->id ==val)
	{
    current = current->next;
	cout<<"Data Founded Successfully "<<endl;
    }
	break;
   }
 
}
 
void node::show() // display fun
{
	
if(head!=NULL)
{
	cout<<"*************************************************"<<endl;
	cout<<"\t Student DATA :"<<endl;
	cout<<"*************************************************"<<endl;
	current=head;
	while(current!=NULL)
	{
	cout<<"Id is: "<<current->id<<" Name is: "<<current->name<<endl<<endl;
	current=current->next;
	}
	
}
else{
	cout<<"NO DATA"<<endl;
}
}

void node:: del() // delete fun
 {
  int pos;
  cout<<"Enter position to delete "<<endl;
  cin>>pos;
	
 if (size==0) // if no node
 {
  cout<<"There is No Data To Delete "<<endl;	
 }

 else if(pos==1&&pos<size) // head
 {
	current=head;
	head=head->next;
	delete current;
	size--;
 }

 else if(pos>1&&pos<size) // mid
 {
  current=head;
  c=head;
  for(int i=1;i<pos;i++)
 {
  c=current;
  current=current->next; 
 }
  c->next=current->next;
  delete current;
  size--;
 }

 else if(pos==size) // end
 {
  c=head;
  current=head;
  for(int i=1;i<pos;i++)
 {
  c=current;
  current=current->next;
 }
  tail=c;
  c->next=NULL;
  delete current;	
  size--;
 }
 } 

void node:: update() //update fun
{
  int val,pos;;
  string val2;

  cout<<"Enetr Rollno To Update "<<endl;
  cin>>val; 
  cout<<"Enetr Name To Update "<<endl;
  cin>>val2;
  cout<<"Enetr Position To Update "<<endl;
  cin>>pos;
  
  if (size==0) // if no node
 {
  cout<<"there is no data to update"<<endl;	
 }
 
 else if (pos==1) // head
 {
 head->id=val;
 head->name=val2;	
 } 
 
 else if(pos>1&&pos<size) // middle
 {
 current=head;
 for(int i=1;i<pos;i++)
 {
 current=current->next;	
 }	
 current->id=val;
 current->name=val2;
 }
 
 else if(pos==size) // end
 {
 tail->id=val;
 tail->name=val2;
 }
}


void node:: traverseh()
{
    temp = head;
    while (temp != NULL)
    {
    cout<<temp->id<<endl;
    cout<<temp->name<<endl;
    temp = temp->next;
    }
    cout<<endl;
}
void node:: traverset()
{
    temp = tail;
    while (temp != NULL)
    {
    cout<<temp->id<<endl;
    cout<<temp->name<<endl;
    temp = temp->prev;
    }
    cout<<endl;
}



main()
{
    cout<<"*************************************************"<<endl;
    cout<<"\t STUDENT DATABASE SYSTEM "<<endl;
    cout<<"*************************************************"<<endl;
    node obj;
	int choice;
	while(1)
	{
		cout<<"Press 1 To Add New Student "<<endl;
		cout<<"Press 2 To Search Student "<<endl;	
		cout<<"Press 3 To Display Student "<<endl;
		cout<<"Press 4 To Update Student "<<endl;
		cout<<"Press 5 To Delete Student "<<endl;
	    cout<<"Press 6 To Sort From Head "<<endl;
		cout<<"Press 7 To Sort From Tail "<<endl;
		
		cin>>choice;
		switch(choice)
		{
		case 1:
		obj.add();
		break;
			
		case 2:
		obj.search();
		break;
		
		case 3:
		obj.show();
		break;
			
		case 4:
		obj.update();
		break;
			
		case 5:
		obj.del();
		break;	
		
		case 6:
		obj.traverseh();
		break;
			
		case 7:
		obj.traverset();
		break;		
		}
	}	
}
