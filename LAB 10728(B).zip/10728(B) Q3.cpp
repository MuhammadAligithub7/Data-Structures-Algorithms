#include<iostream>
using namespace std;
class node
{
	
	int id;
	int size;
	node *next;
	node *prev;
	node *head,*tail,*temp,*current,*c;

	public:
	node()
	{
	head= NULL;
	tail= NULL;
	current=NULL;
	c=NULL;
	temp=NULL;	
	}
		
	void add();
	void search();
	void show();

};

void node::add() // insert fun
{
	if(size==10)
	{
		cout<<"cannot insert anymore"<<endl;
	}
	else
	{
	int val;
	cout<<"Enter any element "<<endl;
	cin>>val;	
			
	temp = new node();
	temp->next=NULL;
	temp->prev=NULL;
	temp->id=val;
	size++;
	
	if(head==NULL)
	{
	head=temp;
	tail=temp;
	}
	else
	{
	tail->next=temp;
	tail->prev=tail;
	tail=tail->next;	
	}	
	}
	
}

void node::search() // search fun
{
	int val;
	cout<<"enter any elemnet to search "<<endl;
	cin>>val;
	
	if(head==NULL)
	{
	cout<<"No Data"<<endl;
	}
	
    current = head;
    while(current!=NULL) 
    {
    if(current->id ==val)
	{
    current = current->next;
    }
    cout<<"TRUE "<<endl;
    break;
   }
}
 
main()
{
    node obj;
	int choice;
	while(1)
	{
	cout<<"Press 1 To Insert "<<endl;
	cout<<"Press 2 To Search "<<endl;	
		
	cin>>choice;
	switch(choice)
	{
	case 1:
	obj.add();
	break;
			
	case 2:
	obj.search();
	break;	
	}
	}	
}
