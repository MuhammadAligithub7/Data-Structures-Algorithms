#include<iostream>
using namespace std;
class c_queue
{
	private:
	int front;
	int rear;
	int count;
	int array[10];
	
	public:
	queue() // default constructor
  {  
	front=-1;
	rear=1;
	count=0;
	for(int i=0;i<10;i++)
	{
	array[i]=0;	
	}
  }	

bool isempty() // empty fun
 {
   if(front==-1&&rear==-1)
	{
	return true;
	}
   else
    return false;	
 }

bool isfull() // full fun
 { 
	if((rear+1)%10==front)
	{
	return true;
	}
	else
	return false;
 }
  
 void enqueue(int val) // add fun
 {
	if(isfull())
	{
	cout<<"Queue Is  Full "<<endl;
	}
	else if(isempty())
	{
	rear=0,front=0;
	array[rear]=val;
	}
	else
	{
	rear=(rear+1)%10;
	array[rear]=val;
	}
	count++;
	cout<<val<<" is inqueued in queue "<<endl;	
 } 

int dequeue() // delete fun
 { 
	int x;
  if(isempty())
	{
	cout<<"Queue Is Empty "<<endl;
	return x;
	}
	else if(rear==front)
	{
	x=array[rear];
	rear=-1,front=-1;
	count--;
	return x;
	}
	else
	{
	cout<<"\nvalue dequeued from queue is : "<<array[front]<<endl;
	x=array[front];
	array[front]=0;
	front=(front+1)%10;
	count--;
	return x;	
	}
 } 

int queue_count() // count fun
{
	return (count);
}

void display()
 { 
	cout<<"\nAll The Values In Queue"<<endl;
    for(int i=0;i<10;i++)
	{
	cout<<array[i]<<" ";
	}	
	cout<<endl;
 }			
};

main()
 {
 	c_queue obj;
 	
 	obj.enqueue(10);
 	obj.enqueue(15);
 	obj.enqueue(20);
 	obj.enqueue(25);
 	obj.enqueue(30);
 	obj.enqueue(35);
 	obj.enqueue(40);
 	obj.enqueue(45);
 	obj.enqueue(50);
 	obj.enqueue(60);
 	
 	obj.dequeue();
 	obj.dequeue();
 	obj.dequeue();
 	
 	obj.display(); 	
 }
